                             UVM Reference Flow
                                Version 1.1 
                                April 2012


Terms and Conditions
--------------------

The terms and conditions to use the UVM Reference Flow are governed by the 
following Licenses

1. All the Open Cores Design included in the UVM Reference Flow are governed
   by GNU LGPL License Version 3. A copy of the License is available at

   ./README_GNU_LGPL_License.txt which is also available online at 
   http://www.gnu.org/licenses/lgpl-3.0.txt

2. All the remaining contents (other than Open Cores Design) is distributed under 
   Apache License Version 2.0. A copy of the Apache License Version 2.0 is
   available at

   ./README_Apache_License.txt which is also available online at
   http://www.apache.org/licenses/

