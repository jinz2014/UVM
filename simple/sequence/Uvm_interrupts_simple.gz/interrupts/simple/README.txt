This example shows how to implement a simple interrupt response routine using
grab() within the ISR sequence.

To compile and run the simulation, please use the make file:

make all - Compile and run
make build - Compile only
make sim  - Run the simulation in command line mode

The Makefile assumes the use of Questa 10.0b or a later version with
built-in UVM support
